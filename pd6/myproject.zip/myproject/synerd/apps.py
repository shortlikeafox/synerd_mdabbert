from django.apps import AppConfig


class SynerdConfig(AppConfig):
    name = 'synerd'
